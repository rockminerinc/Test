<div id="content">

 

<div class="alert alert-danger bs-alert-old-docs">

<?php echo  $msg;?>

</div>

</div>
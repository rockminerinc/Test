<div id="content">

 
<?php echo form_open('c=home&m=reboot'); ?>

<input name="reboot" value="Reboot" type="submit"   class="btn btn-large 	btn-primary">
 
<?php echo form_close(); ?>

</div>